import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { generateKeyPair, generateGroupKey, encrypt, decrypt } from '../utils/crypto';
import type { EncryptionKey, Group, SecurityContext } from '../types/security';

interface KeyState {
  keys: EncryptionKey[];
  groups: Group[];
  activeKeyId: string | null;

  createKey: (name: string, email: string, passphrase: string, context: SecurityContext) => Promise<EncryptionKey>;
  importKey: (name: string, email: string, publicKey: string, context: SecurityContext) => Promise<EncryptionKey>;
  createGroup: (name: string, memberIds: string[], context: SecurityContext) => Promise<Group>;
  deleteKey: (id: string) => void;
  deleteGroup: (id: string) => void;
  setActiveKey: (id: string | null) => void;
  encryptGroupMessage: (groupId: string, message: string) => Promise<string>;
  decryptGroupMessage: (groupId: string, encryptedMessage: string) => Promise<string>;
  addGroupMember: (groupId: string, memberId: string) => Promise<void>;
  removeGroupMember: (groupId: string, memberId: string) => Promise<void>;
  rotateGroupKey: (groupId: string) => Promise<void>;
}

export const useKeyStore = create<KeyState>()(
  persist(
    (set, get) => ({
      keys: [],
      groups: [],
      activeKeyId: null,

      createKey: async (name, email, passphrase, context) => {
        const keyPair = await generateKeyPair(name, email, passphrase);
        const key: EncryptionKey = {
          id: crypto.randomUUID(),
          name,
          email,
          type: 'own',
          publicKey: keyPair.publicKey,
          privateKey: keyPair.privateKey,
          securityContext: context,
          created: new Date().toISOString()
        };
        set((state) => ({ keys: [...state.keys, key] }));
        return key;
      },

      importKey: async (name, email, publicKey, context) => {
        const key: EncryptionKey = {
          id: crypto.randomUUID(),
          name,
          email,
          type: 'contact',
          publicKey,
          securityContext: context,
          created: new Date().toISOString()
        };
        set((state) => ({ keys: [...state.keys, key] }));
        return key;
      },

      createGroup: async (name, memberIds, context) => {
        const { keys } = get();
        const members = memberIds
          .map(id => {
            const key = keys.find(k => k.id === id);
            return key ? {
              keyId: key.id,
              name: key.name,
              email: key.email
            } : null;
          })
          .filter((m): m is NonNullable<typeof m> => m !== null);

        if (members.length === 0) {
          throw new Error('No valid members selected');
        }

        // Генерируем групповой ключ
        const memberKeys = members.map(m => keys.find(k => k.id === m.keyId)!);
        const groupKey = await generateGroupKey(memberKeys);

        const group: Group = {
          id: crypto.randomUUID(),
          name,
          members,
          groupKey: {
            public: groupKey.publicKey,
            memberKeys: groupKey.memberKeys
          },
          securityContext: context,
          created: new Date().toISOString()
        };

        set((state) => ({ groups: [...state.groups, group] }));
        return group;
      },

      deleteKey: (id) => set((state) => ({
        keys: state.keys.filter(k => k.id !== id),
        activeKeyId: state.activeKeyId === id ? null : state.activeKeyId,
        // Удаляем ключ из всех групп
        groups: state.groups.map(group => ({
          ...group,
          members: group.members.filter(m => m.keyId !== id),
          groupKey: group.groupKey ? {
            ...group.groupKey,
            memberKeys: group.groupKey.memberKeys.filter(mk => mk.memberId !== id)
          } : undefined
        }))
      })),

      deleteGroup: (id) => set((state) => ({
        groups: state.groups.filter(g => g.id !== id)
      })),

      setActiveKey: (id) => set({ activeKeyId: id }),

      encryptGroupMessage: async (groupId, message) => {
        const { groups } = get();
        const group = groups.find(g => g.id === groupId);
        if (!group?.groupKey) {
          throw new Error('Group not found or no key available');
        }
        return await encrypt(message, [group.groupKey.public]);
      },

      decryptGroupMessage: async (groupId, encryptedMessage) => {
        const { groups, keys, activeKeyId } = get();
        const group = groups.find(g => g.id === groupId);
        if (!group?.groupKey) {
          throw new Error('Group not found or no key available');
        }

        const activeKey = keys.find(k => k.id === activeKeyId);
        if (!activeKey?.privateKey) {
          throw new Error('No active private key');
        }

        const memberKey = group.groupKey.memberKeys.find(mk => mk.memberId === activeKey.id);
        if (!memberKey) {
          throw new Error('Not a group member');
        }

        const decryptedGroupKey = await decrypt(memberKey.encryptedKey, activeKey.privateKey, '');
        const decrypted = await decrypt(encryptedMessage, decryptedGroupKey.data as string, '');
        return decrypted.data as string;
      },

      addGroupMember: async (groupId, memberId) => {
        const { groups, keys } = get();
        const group = groups.find(g => g.id === groupId);
        const member = keys.find(k => k.id === memberId);

        if (!group || !member) {
          throw new Error('Group or member not found');
        }

        if (group.members.some(m => m.keyId === memberId)) {
          throw new Error('Member already in group');
        }

        const newMember = {
          keyId: member.id,
          name: member.name,
          email: member.email
        };

        // Если есть групповой ключ, шифруем его для нового участника
        if (group.groupKey) {
          const memberKey = await encrypt(group.groupKey.public, [member.publicKey]);
          group.groupKey.memberKeys.push({
            memberId: member.id,
            encryptedKey: memberKey as string
          });
        }

        set((state) => ({
          groups: state.groups.map(g => 
            g.id === groupId 
              ? { ...g, members: [...g.members, newMember] }
              : g
          )
        }));
      },

      removeGroupMember: async (groupId, memberId) => {
        const { groups } = get();
        const group = groups.find(g => g.id === groupId);

        if (!group) {
          throw new Error('Group not found');
        }

        // Удаляем участника и его ключ
        set((state) => ({
          groups: state.groups.map(g => 
            g.id === groupId 
              ? {
                  ...g,
                  members: g.members.filter(m => m.keyId !== memberId),
                  groupKey: g.groupKey ? {
                    ...g.groupKey,
                    memberKeys: g.groupKey.memberKeys.filter(mk => mk.memberId !== memberId)
                  } : undefined
                }
              : g
          )
        }));
      },

      rotateGroupKey: async (groupId) => {
        const { groups, keys } = get();
        const group = groups.find(g => g.id === groupId);

        if (!group) {
          throw new Error('Group not found');
        }

        const memberKeys = group.members.map(m => 
          keys.find(k => k.id === m.keyId)!
        );

        const newGroupKey = await generateGroupKey(memberKeys);

        set((state) => ({
          groups: state.groups.map(g =>
            g.id === groupId
              ? {
                  ...g,
                  groupKey: {
                    public: newGroupKey.publicKey,
                    memberKeys: newGroupKey.memberKeys
                  }
                }
              : g
          )
        }));
      }
    }),
    { 
      name: 'key-store',
      // Не сохраняем приватные ключи в localStorage
      partialize: (state) => ({
        ...state,
        keys: state.keys.map(key => ({
          ...key,
          privateKey: undefined
        }))
      })
    }
  )
);
