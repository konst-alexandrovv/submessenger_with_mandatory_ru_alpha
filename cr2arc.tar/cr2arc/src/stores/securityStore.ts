import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { SecurityContext, SimplifiedLabel, MandatoryLabel } from '../types/security';

// Проверка поддержки BigInt
if (typeof BigInt === 'undefined') {
 throw new Error('This environment does not support BigInt, which is required for security labels');
}

// Максимальные значения уровней
const MAX_CONFIDENTIALITY_LEVEL = 255;        // 8 бит
const MAX_CONFIDENTIALITY_CATEGORIES = 64n;   // 64-битная маска
const MAX_INTEGRITY_LEVEL = 63;               // По умолчанию 6 уровней (0b111111)

const mandatoryMap = {
 'public': {
   confidentialityLevel: 0,
   confidentialityCategories: 0n,
   integrityLevel: 0
 },
 'internal': {
   confidentialityLevel: 1,
   confidentialityCategories: 1n,
   integrityLevel: 3  // 0b011
 },
 'confidential': {
   confidentialityLevel: 2,
   confidentialityCategories: 3n,  // 0b11
   integrityLevel: 7   // 0b111
 },
 'secret': {
   confidentialityLevel: 3,
   confidentialityCategories: 7n,  // 0b111
   integrityLevel: 15  // 0b1111
 }
} as const;

interface SecurityState {
 isAdvancedMode: boolean;
 currentContext: SecurityContext;
 simpleLabel: SimplifiedLabel;
 setAdvancedMode: (mode: boolean) => void;
 setContext: (context: SecurityContext) => void;
 setSimpleLabel: (label: SimplifiedLabel) => void;
}

export const useSecurityStore = create<SecurityState>()(
 persist(
   (set) => ({
     isAdvancedMode: false,
     currentContext: {
       label: mandatoryMap.public,
       attributes: {}
     },
     simpleLabel: {
       level: 'public',
       name: 'Публичный'
     },
     setAdvancedMode: (mode) => set({ isAdvancedMode: mode }),
     setContext: (context) => set({ currentContext: context }),
     setSimpleLabel: (label) => set({
       simpleLabel: label,
       currentContext: {
         label: mandatoryMap[label.level],
         attributes: {}
       }
     })
   }),
   {
     name: 'security-store',
     // Не сохраняем некоторые поля
     partialize: (state) => ({
       isAdvancedMode: state.isAdvancedMode,
       simpleLabel: state.simpleLabel,
       currentContext: {
         label: {
           confidentialityLevel: state.currentContext.label.confidentialityLevel,
           confidentialityCategories: state.currentContext.label.confidentialityCategories,
           integrityLevel: state.currentContext.label.integrityLevel
         },
         attributes: state.currentContext.attributes
       }
     })
   }
 )
);

export function validateSecurityContext(context: SecurityContext): boolean {
 const { label } = context;

 // Проверка уровня конфиденциальности
 if (label.confidentialityLevel < 0 || label.confidentialityLevel > MAX_CONFIDENTIALITY_LEVEL) {
   return false;
 }

 // Проверка уровня целостности
 if (label.integrityLevel < 0 || label.integrityLevel > MAX_INTEGRITY_LEVEL) {
   return false;
 }

 // Проверка категорий (должны быть в пределах маски)
 if (label.confidentialityCategories < 0n || label.confidentialityCategories > MAX_CONFIDENTIALITY_CATEGORIES) {
   return false;
 }

 return true;
}

export function checkAccess(subject: SecurityContext, object: SecurityContext): boolean {
 const { confidentialityLevel: sLevel, confidentialityCategories: sCat, integrityLevel: sInt } = subject.label;
 const { confidentialityLevel: oLevel, confidentialityCategories: oCat, integrityLevel: oInt } = object.label;

 // Проверка уровня доступа
 if (sLevel < oLevel) {
   return false;
 }

 // Проверка категорий
 if ((sCat & oCat) !== oCat) {
   return false;
 }

 // Проверка целостности
 if ((sInt & oInt) !== oInt) {
   return false;
 }

 return true;
}
