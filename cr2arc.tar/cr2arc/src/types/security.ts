export type SecurityLevel = 'public' | 'internal' | 'confidential' | 'secret';

export interface MandatoryLabel {
  // Уровень конфиденциальности (0-255)
  confidentialityLevel: number;
  
  // 64-битная маска категорий конфиденциальности
  confidentialityCategories: bigint;
  
  // Уровень целостности (0-63 по умолчанию, или до 0xFFFFFFFF при 32 уровнях)
  integrityLevel: number;
}

export interface SimplifiedLabel {
  level: SecurityLevel;
  name: string;
}

export interface SecurityContext {
  label: MandatoryLabel;
  
  // Дополнительные мандатные атрибуты
  attributes: {
    // Контейнер может содержать сущности с разными классификационными метками
    ccnr?: boolean;
    
    // Для сущностей с минимальной меткой - игнорирование мандатных правил
    ehole?: boolean;
    
    // Для сущностей с максимальной меткой - разрешение записи снизу вверх
    whole?: boolean;
  };
  
  // PARSEC-привилегии
  privileges?: {
    PARSEC_CAP_CHMAC?: boolean;       // Изменение меток конфиденциальности
    PARSEC_CAP_IGNMACCAT?: boolean;   // Игнорирование категорий для ccnr
    PARSEC_CAP_IGNMACLVL?: boolean;   // Игнорирование уровней для ccnr
    PARSEC_CAP_CCNR_RELAX?: boolean;  // Релаксация правил ccnr
  };
}

export interface EncryptionKey {
  id: string;
  name: string;
  email: string;
  type: 'own' | 'contact';
  publicKey: string;
  privateKey?: string;
  securityContext: SecurityContext;
  created: string;
}

export interface Group {
  id: string;
  name: string;
  members: Array<{
    keyId: string;
    name: string;
    email: string;
  }>;
  groupKey?: {
    public: string;
    memberKeys: Array<{
      memberId: string;
      encryptedKey: string;
    }>;
  };
  securityContext: SecurityContext;
  created: string;
}

// Функции проверки мандатного доступа
export function checkWriteAccess(subject: SecurityContext, object: SecurityContext): boolean {
  const { confidentialityLevel: sLevel, confidentialityCategories: sCat, integrityLevel: sInt } = subject.label;
  const { confidentialityLevel: oLevel, confidentialityCategories: oCat, integrityLevel: oInt } = object.label;

  // Запись разрешена если уровни и категории совпадают, а целостность субъекта не ниже
  return sLevel === oLevel && 
         sCat === oCat && 
         sInt >= oInt;
}

export function checkReadAccess(subject: SecurityContext, object: SecurityContext): boolean {
  const { confidentialityLevel: sLevel, confidentialityCategories: sCat } = subject.label;
  const { confidentialityLevel: oLevel, confidentialityCategories: oCat } = object.label;

  // Чтение разрешено если уровень субъекта не ниже и все категории объекта входят в категории субъекта
  return sLevel >= oLevel && 
         (sCat & oCat) === oCat;
}
