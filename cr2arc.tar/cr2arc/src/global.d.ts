/// <reference types="vite/client" />

declare module '*.svg' {
  const content: string;
  export default content;
}

interface Window {
  electron: {
    send: (channel: string, data: any) => void;
    receive: (channel: string, func: Function) => void;
  };
  fs: {
    readFile: (path: string, options?: { encoding?: string }) => Promise<Uint8Array | string>;
  };
}
