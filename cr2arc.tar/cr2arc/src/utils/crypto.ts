import * as openpgp from 'openpgp';

export interface KeyPair {
  publicKey: string;
  privateKey: string;
}

export interface GroupKeyPair {
  publicKey: string;
  memberKeys: Array<{
    memberId: string;
    encryptedKey: string;
  }>;
}

export async function generateKeyPair(name: string, email: string, passphrase: string): Promise<KeyPair> {
  try {
    const { privateKey, publicKey } = await openpgp.generateKey({
      type: 'ecc' as any,
      curve: 'curve25519' as any,  // Наиболее универсальная кривая
      userIDs: [{ name, email }],
      passphrase,
      format: 'armored'
    });

    return { privateKey, publicKey };
  } catch (error) {
    throw new Error(`Ошибка генерации ключей: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function generateGroupKey(memberKeys: any[]): Promise<GroupKeyPair> {
  try {
    // Генерируем групповой ключ
    const groupKeyPair = await openpgp.generateKey({
      type: 'ecc' as any,
      curve: 'curve25519' as any,  // Наиболее универсальная кривая
      userIDs: [{ name: 'Group Key', email: 'group@local' }],
      format: 'armored'
    });

    // Шифруем его для каждого участника
    const memberKeysPromises = memberKeys.map(async (member) => ({
      memberId: member.id,
      encryptedKey: await encrypt(groupKeyPair.privateKey, [member.publicKey])
    }));

    const encryptedMemberKeys = await Promise.all(memberKeysPromises);

    return {
      publicKey: groupKeyPair.publicKey,
      memberKeys: encryptedMemberKeys
    };
  } catch (error) {
    throw new Error(`Ошибка генерации группового ключа: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function encrypt(data: string | Uint8Array, publicKeys: string[], signing?: { key: string, passphrase: string }) {
  try {
    const encryptionKeys = await Promise.all(
      publicKeys.map(key => openpgp.readKey({ armoredKey: key }))
    );

    let signingKey;
    if (signing) {
      const privateKey = await openpgp.decryptKey({
        privateKey: await openpgp.readPrivateKey({ armoredKey: signing.key }),
        passphrase: signing.passphrase
      });
      signingKey = privateKey;
    }

    const message = typeof data === 'string'
      ? await openpgp.createMessage({ text: data })
      : await openpgp.createMessage({ binary: data });

    const encrypted = await openpgp.encrypt({
      message,
      encryptionKeys,
      signingKeys: signingKey
    });

    return encrypted;
  } catch (error) {
    throw new Error(`Ошибка шифрования: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function decrypt(encryptedData: string | Uint8Array, privateKey: string, passphrase: string) {
  try {
    const message = typeof encryptedData === 'string'
      ? await openpgp.readMessage({ armoredMessage: encryptedData })
      : await openpgp.readMessage({ binaryMessage: encryptedData });

    const decryptionKey = await openpgp.decryptKey({
      privateKey: await openpgp.readPrivateKey({ armoredKey: privateKey }),
      passphrase
    });

    const { data: decrypted, signatures } = await openpgp.decrypt({
      message,
      decryptionKeys: decryptionKey,
      expectSigned: false
    });

    return {
      data: decrypted,
      verified: signatures.length > 0 && await signatures[0].verified
    };
  } catch (error) {
    throw new Error(`Ошибка расшифрования: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
