import type { SecurityContext } from '../types/security';

export function checkAccess(userContext: SecurityContext, targetContext: SecurityContext): boolean {
  const { label: userLabel } = userContext;
  const { label: targetLabel } = targetContext;

  // Проверка уровня конфиденциальности
  if (userLabel.confidentialityLevel < targetLabel.confidentialityLevel) {
    return false;
  }

  // Проверка категорий
  if ((userLabel.confidentialityCategories & targetLabel.confidentialityCategories) !== targetLabel.confidentialityCategories) {
    return false;
  }

  // Проверка целостности
  if ((userLabel.integrityLevel & targetLabel.integrityLevel) !== targetLabel.integrityLevel) {
    return false;
  }

  return true;
}

export function combineSecurityContexts(contexts: SecurityContext[]): SecurityContext {
  return contexts.reduce((acc, curr) => ({
    label: {
      confidentialityLevel: Math.max(acc.label.confidentialityLevel, curr.label.confidentialityLevel),
      confidentialityCategories: acc.label.confidentialityCategories | curr.label.confidentialityCategories,
      integrityLevel: acc.label.integrityLevel & curr.label.integrityLevel,
    },
    attributes: {
      ccnr: acc.attributes.ccnr || curr.attributes.ccnr,
      ehole: acc.attributes.ehole && curr.attributes.ehole,
      whole: acc.attributes.whole || curr.attributes.whole,
    }
  }));
}

export function validateSecurityContext(context: SecurityContext): boolean {
  const { label } = context;
  
  if (label.confidentialityLevel < 0 || label.confidentialityLevel > 255) {
    return false;
  }

  if (label.integrityLevel < 0 || label.integrityLevel > 63) {
    return false;
  }

  return true;
}
