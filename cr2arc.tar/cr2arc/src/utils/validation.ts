export const validateEmail = (email: string): boolean => {
  const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return re.test(email);
};

export const validatePassword = (password: string): { valid: boolean; message?: string } => {
  if (password.length < 12) {
    return { valid: false, message: "Пароль должен содержать минимум 12 символов" };
  }
  
  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: "Должна быть хотя бы одна заглавная буква" };
  }
  
  if (!/[a-z]/.test(password)) {
    return { valid: false, message: "Должна быть хотя бы одна строчная буква" };
  }
  
  if (!/[0-9]/.test(password)) {
    return { valid: false, message: "Должна быть хотя бы одна цифра" };
  }
  
  if (!/[^A-Za-z0-9]/.test(password)) {
    return { valid: false, message: "Должен быть хотя бы один специальный символ" };
  }
  
  return { valid: true };
};

export const validateKeyName = (name: string): boolean => {
  return name.length >= 3 && name.length <= 50;
};

export const validateGroupName = (name: string): boolean => {
  return name.length >= 3 && name.length <= 50;
};
