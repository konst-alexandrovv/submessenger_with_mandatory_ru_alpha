export const messages = {
  ru: {
    common: {
      create: 'Создать',
      delete: 'Удалить',
      edit: 'Редактировать',
      save: 'Сохранить',
      cancel: 'Отмена',
      loading: 'Загрузка...',
      error: 'Ошибка',
      success: 'Успешно'
    },
    security: {
      levels: {
        public: 'Публичный',
        internal: 'Внутренний',
        confidential: 'Конфиденциальный',
        secret: 'Секретный'
      },
      mode: {
        simple: 'Простой режим',
        advanced: 'Расширенный режим'
      }
    },
    keys: {
      create: 'Создать ключ',
      import: 'Импортировать ключ',
      delete: 'Удалить ключ',
      type: {
        own: 'Личный ключ',
        contact: 'Ключ контакта'
      }
    }
  }
} as const;

export type Messages = typeof messages.ru;
export type MessageKey = keyof Messages;

export function getLocalizedMessage(key: keyof typeof messages.ru, lang: keyof typeof messages = 'ru'): string {
  const message = messages[lang]?.[key] || messages.ru[key];
  return typeof message === 'string' ? message : JSON.stringify(message);
}
