export const defaultSecurityConfig = {
  mandatoryLevels: {
    public: {
      level: 0,
      categoryMask: 0n,
      integrityLevel: 0
    },
    internal: {
      level: 1,
      categoryMask: 1n,
      integrityLevel: 3
    },
    confidential: {
      level: 2,
      categoryMask: 3n,
      integrityLevel: 7
    },
    secret: {
      level: 3,
      categoryMask: 7n,
      integrityLevel: 15
    }
  },
  passwordRequirements: {
    minLength: 12,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecial: true
  },
  maxGroupMembers: 100,
  maxKeySize: 4096,
  defaultKeyType: 'ecc',
  defaultCurve: 'curve25519',
  sessionTimeout: 30 * 60 * 1000 // 30 minutes
};
