import * as React from 'react';
import { Button, Card, CardContent, Checkbox, Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, Input, Label } from '@/components/ui';
import { useKeyStore } from '../stores/keyStore';
import { useSecurityStore } from '../stores/securityStore';
import { Plus, Users } from 'lucide-react';

export function GroupPanel() {
  const { keys, groups, createGroup } = useKeyStore();
  const { currentContext } = useSecurityStore();
  const [isOpen, setIsOpen] = React.useState(false);
  const [name, setName] = React.useState('');
  const [selectedKeys, setSelectedKeys] = React.useState<Set<string>>(new Set());

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createGroup(name, Array.from(selectedKeys), currentContext);
      setIsOpen(false);
      setName('');
      setSelectedKeys(new Set());
    } catch (error) {
      console.error('Group creation failed:', error);
    }
  };

  return (
    <div className="space-y-4">
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Создать группу
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Создание группы</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Название группы</Label>
              <Input
                id="name"
                value={name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Участники</Label>
              <div className="max-h-60 overflow-y-auto space-y-2">
                {keys.map(key => (
                  <div key={key.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={key.id}
                      checked={selectedKeys.has(key.id)}
                      onCheckedChange={(checked) => {
                        const newKeys = new Set(selectedKeys);
                        if (checked) {
                          newKeys.add(key.id);
                        } else {
                          newKeys.delete(key.id);
                        }
                        setSelectedKeys(newKeys);
                      }}
                    />
                    <Label htmlFor={key.id}>
                      {key.name} ({key.email})
                    </Label>
                  </div>
                ))}
              </div>
            </div>
            <Button type="submit" className="w-full">
              Создать группу
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <div className="grid gap-4">
        {groups.map(group => (
          <Card key={group.id}>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Users className="h-4 w-4" />
                <h3 className="font-medium">{group.name}</h3>
              </div>
              <div className="space-y-1">
                {group.members.map(member => (
                  <p key={member.keyId} className="text-sm text-muted-foreground">
                    {member.name} ({member.email})
                  </p>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
