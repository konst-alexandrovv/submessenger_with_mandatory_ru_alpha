import * as React from 'react';

interface DialogTriggerProps {
  children: React.ReactNode;
  asChild?: boolean;
}

export const DialogTrigger = ({ children }: DialogTriggerProps) => (
  <div onClick={(e) => e.stopPropagation()}>
    {children}
  </div>
);
