import { cn } from '@/utils/cn';

export const Textarea = ({ className, ...props }: React.TextareaHTMLAttributes<HTMLTextAreaElement>) => (
  <textarea
    className={cn('px-3 py-2 border rounded-md min-h-[100px]', className)}
    {...props}
  />
);
