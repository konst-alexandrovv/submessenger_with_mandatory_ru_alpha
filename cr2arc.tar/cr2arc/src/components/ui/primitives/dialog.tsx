import { DialogProps } from '@/types/ui';
import { DialogTriggerProps } from '@/types/ui';

export const Dialog = ({ children, open, onOpenChange }: DialogProps) => {
  if (!open) return null;
  
  return (
    <div className="fixed inset-0 z-50 bg-black/50" onClick={() => onOpenChange?.(false)}>
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg p-4" onClick={e => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
};

export const DialogContent = ({ children }: { children: React.ReactNode }) => (
  <div className="space-y-4">{children}</div>
);

export const DialogHeader = ({ children }: { children: React.ReactNode }) => (
  <div className="mb-4">{children}</div>
);

export const DialogTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-lg font-semibold">{children}</h2>
);

export const DialogTrigger = ({ children, asChild }: DialogTriggerProps) => (
  <div onClick={(e) => e.stopPropagation()}>
    {children}
  </div>
);
