# UI Primitives

This directory contains primitive UI components that are used throughout the application.

## Components Structure

- alert.tsx - Alert component with title and description
- button.tsx - Button component with variants
- card.tsx - Card container component
- checkbox.tsx - Checkbox input component
- dialog.tsx - Modal dialog component
- dropdown-menu.tsx - Dropdown menu component
- input.tsx - Text input component
- label.tsx - Form label component
- radio-group.tsx - Radio button group
- select.tsx - Select dropdown component
- slider.tsx - Range slider component
- switch.tsx - Toggle switch component
- tabs.tsx - Tabbed interface component
- textarea.tsx - Multiline text input
- toast.tsx - Toast notification component
- use-toast.tsx - Toast hook and provider

Each component is designed to be:
- Self-contained
- Typed with TypeScript
- Styled with Tailwind CSS
- Accessible following WAI-ARIA guidelines
