import { cn } from '@/utils/cn';
import React, { useState, useRef, useEffect } from 'react';

interface DropdownMenuProps {
  children: React.ReactNode;
  className?: string;
}

interface DropdownChildProps {
  open?: boolean;
  setOpen?: (open: boolean) => void;
  [key: string]: any;
}

export const DropdownMenu = ({ children, className }: DropdownMenuProps) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={ref} className={cn('relative', className)}>
      {React.Children.map(children, child => {
        if (React.isValidElement<DropdownChildProps>(child)) {
          return React.cloneElement(child, {
            ...child.props,
            open,
            setOpen
          });
        }
        return child;
      })}
    </div>
  );
};

export const DropdownMenuTrigger = React.forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement> & { open?: boolean; setOpen?: (open: boolean) => void }
>(({ children, open, setOpen, ...props }, ref) => (
  <button
    ref={ref}
    onClick={() => setOpen?.(!open)}
    {...props}
  >
    {children}
  </button>
));

export const DropdownMenuContent = ({
  children,
  className,
  open
}: {
  children: React.ReactNode;
  className?: string;
  open?: boolean;
}) => {
  if (!open) return null;

  return (
    <div className={cn(
      'absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5',
      className
    )}>
      {children}
    </div>
  );
};

export const DropdownMenuItem = React.forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement>
>(({ className, ...props }, ref) => (
  <button
    ref={ref}
    className={cn(
      'w-full text-left px-4 py-2 text-sm hover:bg-gray-100',
      className
    )}
    {...props}
  />
));

DropdownMenuTrigger.displayName = 'DropdownMenuTrigger';
DropdownMenuItem.displayName = 'DropdownMenuItem';
