import { InputProps } from '@/types/ui';
import { cn } from '@/utils/cn';

export const Input = ({ className, ...props }: InputProps) => (
  <input
    className={cn('px-3 py-2 border rounded-md', className)}
    {...props}
  />
);
