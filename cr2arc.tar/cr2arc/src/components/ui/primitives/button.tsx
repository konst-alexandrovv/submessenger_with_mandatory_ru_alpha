import { ButtonProps } from '@/types/ui';
import { cn } from '@/utils/cn';

export const Button = ({ className, variant = 'default', ...props }: ButtonProps) => (
  <button
    className={cn(
      'px-4 py-2 rounded-md',
      variant === 'default' && 'bg-primary text-white',
      variant === 'outline' && 'border border-primary text-primary',
      variant === 'ghost' && 'text-primary hover:bg-primary/10',
      className
    )}
    {...props}
  />
);
