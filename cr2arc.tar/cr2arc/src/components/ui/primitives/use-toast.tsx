import * as React from 'react';
import { Toast as RadixToast, ToastProvider as RadixToastProvider, ToastViewport } from '@radix-ui/react-toast';
import { cn } from '@/utils/cn';

export interface ToastProps {
  id: string;
  title?: string;
  description?: string;
  action?: React.ReactNode;
  variant?: 'default' | 'destructive';
}

export interface ToastOptions {
  title?: string;
  description?: string;
  variant?: 'default' | 'destructive';
  duration?: number;
  action?: React.ReactNode;
}

interface ToastContext {
  toasts: ToastProps[];
  addToast: (options: ToastOptions) => void;
  removeToast: (id: string) => void;
}

const ToastContext = React.createContext<ToastContext | null>(null);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = React.useState<ToastProps[]>([]);

  const addToast = React.useCallback((options: ToastOptions) => {
    const id = Math.random().toString(36).slice(2);

    setToasts((prev) => [
      ...prev,
      { id, ...options },
    ]);

    if (options.duration !== 0) {
      setTimeout(() => {
        setToasts((prev) => prev.filter((toast) => toast.id !== id));
      }, options.duration || 3000);
    }
  }, []);

  const removeToast = React.useCallback((id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  }, []);

  const value = React.useMemo(
    () => ({
      toasts,
      addToast,
      removeToast,
    }),
    [toasts, addToast, removeToast]
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
      <ToastViewport className="fixed bottom-0 right-0 p-6 space-y-4 w-full max-w-sm" />
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = React.useContext(ToastContext);

  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }

  return {
    toast: context.addToast,
    dismiss: context.removeToast,
    toasts: context.toasts,
  };
}

export function Toaster() {
  const { toasts } = useToast();

  return (
    <RadixToastProvider>
      {toasts.map(({ id, title, description, variant }) => (
        <RadixToast
          key={id}
          className={cn(
            'bg-white rounded-lg border p-4 shadow-lg',
            variant === 'destructive' && 'bg-red-50 border-red-200'
          )}
        >
          {title && <div className="font-semibold">{title}</div>}
          {description && <div className="text-sm text-gray-500">{description}</div>}
        </RadixToast>
      ))}
    </RadixToastProvider>
  );
}
