import { cn } from '@/utils/cn';

export const RadioGroup = ({
  value,
  onValueChange,
  className,
  children
}: {
  value?: string;
  onValueChange?: (value: string) => void;
  className?: string;
  children: React.ReactNode
}) => (
  <div className={cn('space-y-2', className)}>{children}</div>
);

export const RadioGroupItem = ({ value, id, className }: { value: string; id?: string; className?: string }) => (
  <button
    id={id}
    role="radio"
    aria-checked={false}
    className={cn(
      'w-4 h-4 rounded-full border',
      className
    )}
  />
);
