import { cn } from '@/utils/cn';

interface SliderProps {
  value: number[];
  max: number;
  step?: number;
  onValueChange: (values: number[]) => void;
  className?: string;
}

export const Slider = ({ value, max, step = 1, onValueChange, className }: SliderProps) => (
  <input
    type="range"
    min={0}
    max={max}
    step={step}
    value={value[0]}
    onChange={(e) => onValueChange([Number(e.target.value)])}
    className={cn('w-full', className)}
  />
);
