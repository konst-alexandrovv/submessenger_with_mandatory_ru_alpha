import { cn } from '@/utils/cn';

export const Switch = ({ checked, onCheckedChange, className }: { checked?: boolean; onCheckedChange?: (checked: boolean) => void; className?: string }) => (
  <button
    role="switch"
    aria-checked={checked}
    className={cn(
      'w-11 h-6 bg-gray-200 rounded-full p-1 transition-colors',
      checked && 'bg-primary',
      className
    )}
    onClick={() => onCheckedChange?.(!checked)}
  >
    <div className={cn(
      'w-4 h-4 bg-white rounded-full transition-transform',
      checked && 'translate-x-5'
    )} />
  </button>
);
