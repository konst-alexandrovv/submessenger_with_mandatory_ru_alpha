import * as React from 'react';
import { cn } from '@/utils/cn';

export interface TabsProps {
  children: React.ReactNode;
  defaultValue: string;
  className?: string;
  value?: string;
  onValueChange?: (value: string) => void;
}

export interface TabsListProps {
  children: React.ReactNode;
  className?: string;
}

export interface TabsTriggerProps {
  children: React.ReactNode;
  value: string;
  className?: string;
  disabled?: boolean;
}

export interface TabsContentProps {
  children: React.ReactNode;
  value: string;
  className?: string;
}

export const Tabs = React.forwardRef<HTMLDivElement, TabsProps>(
  ({ children, defaultValue, value, onValueChange, className }, ref) => {
    const [selectedValue, setSelectedValue] = React.useState(value || defaultValue);

    React.useEffect(() => {
      if (value !== undefined) {
        setSelectedValue(value);
      }
    }, [value]);

    const handleValueChange = (newValue: string) => {
      if (value === undefined) {
        setSelectedValue(newValue);
      }
      onValueChange?.(newValue);
    };

    return (
      <div ref={ref} className={cn("w-full", className)} data-value={selectedValue}>
        {children}
      </div>
    );
  }
);

export const TabsList = React.forwardRef<HTMLDivElement, TabsListProps>(
  ({ children, className }, ref) => (
    <div ref={ref} role="tablist" className={cn("flex", className)}>
      {children}
    </div>
  )
);

export const TabsTrigger = React.forwardRef<HTMLButtonElement, TabsTriggerProps>(
  ({ children, value, className, disabled }, ref) => (
    <button
      ref={ref}
      role="tab"
      data-value={value}
      disabled={disabled}
      className={cn(
        "px-3 py-1.5 text-sm font-medium transition-all",
        "disabled:opacity-50 disabled:cursor-not-allowed",
        className
      )}
    >
      {children}
    </button>
  )
);

export const TabsContent = React.forwardRef<HTMLDivElement, TabsContentProps>(
  ({ children, value, className }, ref) => (
    <div
      ref={ref}
      role="tabpanel"
      data-value={value}
      className={cn("mt-2", className)}
    >
      {children}
    </div>
  )
);

Tabs.displayName = "Tabs";
TabsList.displayName = "TabsList";
TabsTrigger.displayName = "TabsTrigger";
TabsContent.displayName = "TabsContent";
