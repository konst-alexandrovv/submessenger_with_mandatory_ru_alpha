import { cn } from '@/utils/cn';

export const Checkbox = ({ checked, onCheckedChange, id, className }: { checked?: boolean; onCheckedChange?: (checked: boolean) => void; id?: string; className?: string }) => (
  <button
    id={id}
    role="checkbox"
    aria-checked={checked}
    className={cn(
      'w-4 h-4 border rounded',
      checked && 'bg-primary border-primary',
      className
    )}
    onClick={() => onCheckedChange?.(!checked)}
  />
);
