import { cn } from '@/utils/cn';

export const Alert = ({ children, variant = 'default', className }: { children: React.ReactNode; variant?: 'default' | 'destructive'; className?: string; }) => (
  <div className={cn(
    'p-4 rounded-md',
    variant === 'default' && 'bg-primary/10',
    variant === 'destructive' && 'bg-red-100 text-red-900',
    className
  )}>
    {children}
  </div>
);

export const AlertTitle = ({ children }: { children: React.ReactNode }) => (
  <h5 className="font-medium mb-1">{children}</h5>
);

export const AlertDescription = ({ children }: { children: React.ReactNode }) => (
  <div className="text-sm">{children}</div>
);
