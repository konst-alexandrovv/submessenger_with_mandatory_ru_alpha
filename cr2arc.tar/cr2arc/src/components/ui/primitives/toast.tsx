import { Toast, ToastProvider, ToastViewport } from '@radix-ui/react-toast';
import { cn } from '@/utils/cn';

export function Toaster() {
  return (
    <ToastProvider>
      <ToastViewport className="fixed bottom-0 right-0 p-6 space-y-4 w-full max-w-sm" />
    </ToastProvider>
  );
}

interface ToastProps {
  title?: string;
  description?: string;
  variant?: 'default' | 'destructive';
}

export function ToastComponent({ title, description, variant = 'default' }: ToastProps) {
  return (
    <Toast className={cn(
      'bg-white rounded-lg border p-4 shadow-lg',
      variant === 'destructive' && 'bg-red-50 border-red-200'
    )}>
      {title && <div className="font-semibold">{title}</div>}
      {description && <div className="text-sm text-gray-500">{description}</div>}
    </Toast>
  );
}
