import * as React from 'react';
import { Label, RadioGroup, RadioGroupItem } from '@/components/ui';
import { useSecurityStore } from '../stores/securityStore';

export function SimpleSecuritySettings() {
  const { simpleLabel, setSimpleLabel } = useSecurityStore();

  const levels = [
    { value: 'public', label: 'Публичный' },
    { value: 'internal', label: 'Внутренний' },
    { value: 'confidential', label: 'Конфиденциальный' },
    { value: 'secret', label: 'Секретный' }
  ] as const;

  return (
    <RadioGroup
      value={simpleLabel.level}
      onValueChange={(value: string) => 
        setSimpleLabel({
          level: value as 'public' | 'internal' | 'confidential' | 'secret',
          name: levels.find(l => l.value === value)?.label || ''
        })
      }
      className="grid grid-cols-2 gap-4"
    >
      {levels.map(level => (
        <div key={level.value} className="flex items-center space-x-2">
          <RadioGroupItem value={level.value} id={level.value} />
          <Label htmlFor={level.value}>{level.label}</Label>
        </div>
      ))}
    </RadioGroup>
  );
}
