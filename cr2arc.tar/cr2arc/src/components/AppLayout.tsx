import * as React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui';
import { MessageCircle, File, Users, Key } from 'lucide-react';
import { MessagePanel } from './MessagePanel';
import { FilePanel } from './FilePanel';
import { GroupPanel } from './GroupPanel';
import { KeyPanel } from './KeyPanel';
import { SecurityBadge } from './SecurityBadge';
import { useSecurityStore } from '../stores/securityStore';

export function AppLayout() {
  const { simpleLabel } = useSecurityStore();
  
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <h1 className="text-xl font-semibold">Secure Messenger</h1>
          <SecurityBadge />
        </div>
      </header>

      <main className="container mx-auto p-4">
        <Tabs defaultValue="messages" className="space-y-4">
          <TabsList className="grid grid-cols-4 gap-4">
            <TabsTrigger value="messages" className="flex items-center gap-2">
              <MessageCircle className="h-4 w-4" />
              <span>Сообщения</span>
            </TabsTrigger>
            <TabsTrigger value="files" className="flex items-center gap-2">
              <File className="h-4 w-4" />
              <span>Файлы</span>
            </TabsTrigger>
            <TabsTrigger value="groups" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span>Группы</span>
            </TabsTrigger>
            <TabsTrigger value="keys" className="flex items-center gap-2">
              <Key className="h-4 w-4" />
              <span>Ключи</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="messages">
            <MessagePanel />
          </TabsContent>
          <TabsContent value="files">
            <FilePanel />
          </TabsContent>
          <TabsContent value="groups">
            <GroupPanel />
          </TabsContent>
          <TabsContent value="keys">
            <KeyPanel />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
