import { useEffect } from 'react';
import { useSecurityStore } from '../stores/securityStore';
import { checkAccess } from '../utils/securityHelpers';
import type { SecurityContext } from '../types/security';

interface Props {
  required: SecurityContext;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function MandatoryAccessControl({ required, children, fallback }: Props) {
  const { currentContext } = useSecurityStore();
  const hasAccess = checkAccess(currentContext, required);

  return hasAccess ? <>{children}</> : <>{fallback}</>;
}
