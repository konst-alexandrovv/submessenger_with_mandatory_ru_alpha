import * as React from 'react';
import { useState } from 'react';
import { Button, Dialog, DialogContent, DialogHeader, DialogTitle, Input, Label } from '@/components/ui';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (passphrase: string) => void;
}

export function PassphraseDialog({ isOpen, onClose, onSubmit }: Props) {
  const [passphrase, setPassphrase] = useState('');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Введите пароль</DialogTitle>
        </DialogHeader>
        <form onSubmit={(e) => {
          e.preventDefault();
          onSubmit(passphrase);
          setPassphrase('');
        }}>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="passphrase">Пароль для расшифровки</Label>
              <Input
                id="passphrase"
                type="password"
                value={passphrase}
                onChange={(e) => setPassphrase(e.target.value)}
                autoFocus
              />
            </div>
            <Button type="submit" className="w-full">
              Подтвердить
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
