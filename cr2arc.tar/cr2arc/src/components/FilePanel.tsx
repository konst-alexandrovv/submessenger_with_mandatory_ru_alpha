import * as React from 'react';
import { Button, Card, CardContent } from '@/components/ui';
import { useKeyStore } from '../stores/keyStore';
import { encrypt, decrypt } from '../utils/crypto';
import { Upload, Download } from 'lucide-react';

export function FilePanel() {
  const [file, setFile] = React.useState<File | null>(null);
  const { keys, activeKeyId } = useKeyStore();
  const fileRef = React.useRef<HTMLInputElement>(null);
  
  const activeKey = keys.find(k => k.id === activeKeyId);

  const handleEncrypt = async () => {
    if (!activeKey || !file) return;

    try {
      const arrayBuffer = await file.arrayBuffer();
      const encrypted = await encrypt(
        new Uint8Array(arrayBuffer),
        [activeKey.publicKey]
      );

      const blob = new Blob([encrypted], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${file.name}.enc`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setFile(null);
    } catch (error) {
      console.error('Encryption failed:', error);
    }
  };

  const handleDecrypt = async () => {
    if (!activeKey?.privateKey || !file) return;

    try {
      const arrayBuffer = await file.arrayBuffer();
      const { data } = await decrypt(
        new Uint8Array(arrayBuffer),
        activeKey.privateKey,
        '' // TODO: Add passphrase handling
      );

      const blob = new Blob([data as Uint8Array]);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name.replace('.enc', '');
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setFile(null);
    } catch (error) {
      console.error('Decryption failed:', error);
    }
  };

  if (!activeKey) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-muted-foreground">
            Выберите ключ для начала работы
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-6 space-y-4">
        <input
          ref={fileRef}
          type="file"
          className="hidden"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
        />

        <div className="border-2 border-dashed rounded-lg p-8 text-center space-y-4">
          {file ? (
            <>
              <p className="text-sm">{file.name}</p>
              <Button
                onClick={file.name.endsWith('.enc') ? handleDecrypt : handleEncrypt}
                className="w-full"
              >
                {file.name.endsWith('.enc') ? (
                  <>
                    <Download className="h-4 w-4 mr-2" />
                    Расшифровать
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Зашифровать
                  </>
                )}
              </Button>
            </>
          ) : (
            <Button
              variant="ghost"
              onClick={() => fileRef.current?.click()}
              className="w-full h-32"
            >
              Выберите или перетащите файл
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
