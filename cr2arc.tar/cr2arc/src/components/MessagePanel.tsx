import * as React from 'react';
import { Alert, AlertDescription, Button, Card, CardContent, Select, Switch, Textarea } from '@/components/ui';
import { useKeyStore } from '../stores/keyStore';
import { useSecurityStore } from '../stores/securityStore';
import { encrypt, decrypt } from '../utils/crypto';
import { AlertCircle, Lock, Users } from 'lucide-react';

export function MessagePanel() {
  const [message, setMessage] = React.useState('');
  const [encrypted, setEncrypted] = React.useState('');
  const [selectedGroup, setSelectedGroup] = React.useState<string>('');
  const [isGroupMode, setIsGroupMode] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const { 
    keys, 
    groups, 
    activeKeyId, 
    encryptGroupMessage, 
    decryptGroupMessage 
  } = useKeyStore();
  
  const { currentContext } = useSecurityStore();

  const activeKey = keys.find(k => k.id === activeKeyId);
  const selectedGroupData = groups.find(g => g.id === selectedGroup);

  const clearError = () => setError(null);

  const handleEncrypt = async () => {
    if (!activeKey || !message) return;
    
    try {
      clearError();
      if (isGroupMode && selectedGroup) {
        const result = await encryptGroupMessage(selectedGroup, message);
        setEncrypted(result);
      } else {
        const result = await encrypt(
          message,
          [activeKey.publicKey],
          activeKey.type === 'own' ? {
            key: activeKey.privateKey!,
            passphrase: '' // TODO: Add passphrase handling via PassphraseDialog
          } : undefined
        );
        setEncrypted(result);
      }
      setMessage('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка шифрования');
    }
  };

  const handleDecrypt = async () => {
    if (!activeKey?.privateKey || !encrypted) return;
    
    try {
      clearError();
      if (isGroupMode && selectedGroup) {
        const result = await decryptGroupMessage(selectedGroup, encrypted);
        setMessage(result);
      } else {
        const { data, verified } = await decrypt(
          encrypted,
          activeKey.privateKey,
          '' // TODO: Add passphrase handling
        );
        setMessage(data as string);
        if (!verified) {
          setError('Предупреждение: подпись сообщения не подтверждена');
        }
      }
      setEncrypted('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка расшифрования');
    }
  };

  // Проверяем доступ к группе по мандатным меткам
  const canAccessGroup = (group: typeof groups[0]) => {
    const groupLevel = group.securityContext.label.confidentialityLevel;
    const userLevel = currentContext.label.confidentialityLevel;
    const groupCategories = group.securityContext.label.confidentialityCategories;
    const userCategories = currentContext.label.confidentialityCategories;

    return userLevel >= groupLevel && 
           (userCategories & groupCategories) === groupCategories;
  };

  // Фильтруем группы по мандатному доступу
  const accessibleGroups = groups.filter(canAccessGroup);

  if (!activeKey) {
    return (
      <Card>
        <CardContent className="p-6">
          <Alert variant="default">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Выберите ключ для начала работы
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

    return (
    <Card>
      <CardContent className="p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Switch 
              checked={isGroupMode} 
              onCheckedChange={setIsGroupMode} 
              className="group-mode-switch"
            />
            <label htmlFor="group-mode" className="text-sm font-medium">
              Групповой режим
            </label>
          </div>
        </div>

        {isGroupMode && (
          <Select 
            value={selectedGroup} 
            onChange={(e) => setSelectedGroup(e.target.value)}
            className="w-full"
          >
            <option value="">Выберите группу</option>
            {accessibleGroups.map(group => (
              <option key={group.id} value={group.id}>
                {group.name} ({group.members.length} участников)
              </option>
            ))}
          </Select>
        )}

        <div className="space-y-2">
          <Textarea
            placeholder={
              isGroupMode
                ? "Введите сообщение для группы..."
                : "Введите сообщение..."
            }
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={6}
          />
          <Button
            onClick={handleEncrypt}
            disabled={!message || (isGroupMode && !selectedGroup)}
            className="w-full"
          >
            {isGroupMode ? (
              <>
                <Users className="h-4 w-4 mr-2" />
                Зашифровать для группы
              </>
            ) : (
              <>
                <Lock className="h-4 w-4 mr-2" />
                Зашифровать
              </>
            )}
          </Button>
        </div>

        {encrypted && (
          <div className="space-y-2">
            <Textarea
              value={encrypted}
              readOnly
              rows={6}
              className="font-mono text-sm"
            />
            {(activeKey.type === 'own' || 
              (isGroupMode && selectedGroupData?.members.some(m => m.keyId === activeKey.id))) && (
              <Button
                onClick={handleDecrypt}
                variant="outline"
                className="w-full"
              >
                Расшифровать
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
