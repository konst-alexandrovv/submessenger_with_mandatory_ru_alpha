import * as React from 'react';
import { Button, Card, Input } from '@/components/ui';
import { useKeyStore } from '../../stores/keyStore';
import { encrypt, decrypt } from '../../utils/crypto';

interface StoredPassword {
  id: string;
  name: string;
  encryptedPassword: string;
}

export function PasswordManager() {
  const { keys, activeKeyId } = useKeyStore();
  const [passwords, setPasswords] = React.useState<StoredPassword[]>([]);
  const [newPassword, setNewPassword] = React.useState({ name: '', password: '' });
  
  const activeKey = keys.find(k => k.id === activeKeyId);

  const handleStore = async () => {
    if (!activeKey?.privateKey || !newPassword.password) return;

    const encrypted = await encrypt(newPassword.password, [activeKey.publicKey]);
    const stored: StoredPassword = {
      id: crypto.randomUUID(),
      name: newPassword.name,
      encryptedPassword: encrypted as string
    };
    
    setPasswords([...passwords, stored]);
    setNewPassword({ name: '', password: '' });
  };

  const handleReveal = async (stored: StoredPassword) => {
    if (!activeKey?.privateKey) return;

    try {
      const { data } = await decrypt(
        stored.encryptedPassword,
        activeKey.privateKey,
        '' // TODO: Add passphrase handling
      );
      
      await navigator.clipboard.writeText(data as string);
    } catch (error) {
      console.error('Failed to decrypt password:', error);
    }
  };

  return (
    <Card className="p-4 space-y-4">
      <div className="space-y-2">
        <Input
          placeholder="Название"
          value={newPassword.name}
          onChange={e => setNewPassword({ ...newPassword, name: e.target.value })}
        />
        <Input
          type="password"
          placeholder="Пароль"
          value={newPassword.password}
          onChange={e => setNewPassword({ ...newPassword, password: e.target.value })}
        />
        <Button 
          onClick={handleStore}
          disabled={!newPassword.name || !newPassword.password}
          className="w-full"
        >
          Сохранить
        </Button>
      </div>

      <div className="space-y-2">
        {passwords.map(stored => (
          <div 
            key={stored.id}
            className="flex items-center justify-between p-2 border rounded"
          >
            <span>{stored.name}</span>
            <Button
              variant="outline"
              onClick={() => handleReveal(stored)}
              disabled={!activeKey?.privateKey}
            >
              Копировать
            </Button>
          </div>
        ))}
      </div>
    </Card>
  );
}
