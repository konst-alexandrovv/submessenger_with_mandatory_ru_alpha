import * as React from 'react';
import { Button, Card, CardContent, Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, Input, Label } from '@/components/ui';
import { useKeyStore } from '../stores/keyStore';
import { useSecurityStore } from '../stores/securityStore';
import { SecurityBadge } from './SecurityBadge';
import { Plus, Key, User } from 'lucide-react';

export function KeyPanel() {
  const { keys, createKey, importKey, activeKeyId, setActiveKey } = useKeyStore();
  const { currentContext } = useSecurityStore();
  const [isOpen, setIsOpen] = React.useState(false);
  const [keyType, setKeyType] = React.useState<'create' | 'import'>('create');
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    passphrase: '',
    publicKey: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (keyType === 'create') {
        await createKey(formData.name, formData.email, formData.passphrase, currentContext);
      } else {
        await importKey(formData.name, formData.email, formData.publicKey, currentContext);
      }
      setIsOpen(false);
      setFormData({ name: '', email: '', passphrase: '', publicKey: '' });
    } catch (error) {
      console.error('Key operation failed:', error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Добавить ключ
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {keyType === 'create' ? 'Создать ключ' : 'Импортировать ключ'}
              </DialogTitle>
            </DialogHeader>
            <div className="flex space-x-4 mb-4">
              <Button
                variant={keyType === 'create' ? 'default' : 'outline'}
                onClick={() => setKeyType('create')}
              >
                <Key className="h-4 w-4 mr-2" />
                Создать
              </Button>
              <Button
                variant={keyType === 'import' ? 'default' : 'outline'}
                onClick={() => setKeyType('import')}
              >
                <User className="h-4 w-4 mr-2" />
                Импорт
              </Button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Имя</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
              {keyType === 'create' ? (
                <div className="space-y-2">
                  <Label htmlFor="passphrase">Пароль</Label>
                  <Input
                    id="passphrase"
                    type="password"
                    value={formData.passphrase}
                    onChange={e => setFormData({ ...formData, passphrase: e.target.value })}
                    required
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="publicKey">Публичный ключ</Label>
                  <textarea
                    id="publicKey"
                    className="w-full min-h-[100px] p-2 border rounded-md"
                    value={formData.publicKey}
                    onChange={e => setFormData({ ...formData, publicKey: e.target.value })}
                    required
                  />
                </div>
              )}
              <Button type="submit" className="w-full">
                {keyType === 'create' ? 'Создать' : 'Импортировать'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {keys.map(key => (
          <div key={key.id} onClick={() => setActiveKey(key.id)}>
            <Card className={`cursor-pointer ${key.id === activeKeyId ? 'ring-2 ring-primary' : ''}`}>
              <CardContent className="p-4 flex justify-between items-center">
                <div>
                  <h3 className="font-medium">{key.name}</h3>
                  <p className="text-sm text-muted-foreground">{key.email}</p>
                  <p className="text-xs text-muted-foreground">
                    {key.type === 'own' ? 'Мой ключ' : 'Контакт'}
                  </p>
                </div>
                <SecurityBadge />
              </CardContent>
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
}
