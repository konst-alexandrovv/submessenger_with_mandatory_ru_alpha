import * as React from 'react';
import { Input, Label, Slider } from '@/components/ui';
import { useSecurityStore } from '../stores/securityStore';

const MAX_CONFIDENTIALITY = 255;
const MAX_INTEGRITY = 63;

export function AdvancedSecuritySettings() {
  const { currentContext, setContext } = useSecurityStore();

  const handleConfidentialityChange = (value: number) => {
    setContext({
      ...currentContext,
      label: {
        ...currentContext.label,
        confidentialityLevel: value
      }
    });
  };

  const handleCategoriesChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const value = BigInt(`0x${event.target.value}`);
      setContext({
        ...currentContext,
        label: {
          ...currentContext.label,
          confidentialityCategories: value
        }
      });
    } catch (e) {
      console.error('Invalid hexadecimal value');
    }
  };

  const handleIntegrityChange = (value: number) => {
    setContext({
      ...currentContext,
      label: {
        ...currentContext.label,
        integrityLevel: value
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label>Уровень конфиденциальности (0-255)</Label>
        <Slider
          value={[currentContext.label.confidentialityLevel]}
          max={MAX_CONFIDENTIALITY}
          step={1}
          onValueChange={([value]) => handleConfidentialityChange(value)}
        />
      </div>

      <div className="space-y-2">
        <Label>Категории конфиденциальности (hex)</Label>
        <Input
          value={currentContext.label.confidentialityCategories.toString(16)}
          onChange={handleCategoriesChange}
          maxLength={16}
          className="font-mono"
        />
      </div>

      <div className="space-y-2">
        <Label>Уровень целостности (0-63)</Label>
        <Slider
          value={[currentContext.label.integrityLevel]}
          max={MAX_INTEGRITY}
          step={1}
          onValueChange={([value]) => handleIntegrityChange(value)}
        />
      </div>
    </div>
  );
}
