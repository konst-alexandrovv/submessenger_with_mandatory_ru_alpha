import * as React from 'react';
import { Settings } from 'lucide-react';
import { Button, Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, Switch } from '@/components/ui';
import { useSecurityStore } from '../stores/securityStore';
import { AdvancedSecuritySettings } from './AdvancedSecuritySettings';
import { SimpleSecuritySettings } from './SimpleSecuritySettings';

const levelColors = {
  public: 'bg-green-100 text-green-800',
  internal: 'bg-blue-100 text-blue-800',
  confidential: 'bg-yellow-100 text-yellow-800',
  secret: 'bg-red-100 text-red-800'
};

export function SecurityBadge() {
  const { isAdvancedMode, simpleLabel, currentContext, setAdvancedMode } = useSecurityStore();
  const [open, setOpen] = React.useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          className={`${levelColors[simpleLabel.level]} hover:bg-opacity-80`}
        >
          <span className="mr-2">{simpleLabel.name}</span>
          <Settings className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Настройки безопасности</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Расширенный режим</span>
            <Switch
              checked={isAdvancedMode}
              onCheckedChange={setAdvancedMode}
            />
          </div>

          {isAdvancedMode ? (
            <AdvancedSecuritySettings />
          ) : (
            <SimpleSecuritySettings />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
