import { useToast as useToastPrimitive } from '@/components/ui/primitives/use-toast';

interface ToastOptions {
  title?: string;
  description?: string;
  variant?: 'default' | 'destructive';
  duration?: number;
}

export function useCustomToast() {
  const { toast } = useToastPrimitive();

  const showToast = (options: ToastOptions) => {
    toast({
      ...options,
      duration: options.duration || 3000
    });
  };

  const showError = (error: Error | string) => {
    const message = error instanceof Error ? error.message : error;
    showToast({
      title: 'Ошибка',
      description: message,
      variant: 'destructive'
    });
  };

  const showSuccess = (message: string) => {
    showToast({
      title: 'Успешно',
      description: message
    });
  };

  return { showToast, showError, showSuccess };
}
