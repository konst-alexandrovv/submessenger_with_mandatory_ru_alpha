import { useEffect } from 'react';
import { useKeyStore } from '../stores/keyStore';
import { useSecurityStore } from '../stores/securityStore';

export function useKeyboardShortcuts() {
  const { isAdvancedMode, setAdvancedMode } = useSecurityStore();
  const { activeKeyId, setActiveKey, keys } = useKeyStore();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'A') {
        setAdvancedMode(!isAdvancedMode);
      }

      if ((e.ctrlKey || e.metaKey) && /^[1-9]$/.test(e.key)) {
        const index = parseInt(e.key) - 1;
        if (index < keys.length) {
          setActiveKey(keys[index].id);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [keys, setActiveKey, setAdvancedMode, isAdvancedMode]);
}
