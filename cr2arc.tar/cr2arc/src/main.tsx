import * as React from 'react';
import ReactDOM from 'react-dom/client';
import { AppLayout } from './components/AppLayout';
import { ThemeProvider } from './contexts/ThemeContext';
import '../styles/global.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ThemeProvider>
      <AppLayout />
    </ThemeProvider>
  </React.StrictMode>
);
