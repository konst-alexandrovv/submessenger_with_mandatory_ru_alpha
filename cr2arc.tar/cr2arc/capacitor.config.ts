import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.secure.messenger',
  appName: 'Secure Messenger',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  android: {
    buildOptions: {
      keystorePath: 'release.keystore',
      keystoreAlias: 'key0'
    }
  },
  ios: {
    scheme: 'Secure Messenger'
  }
};

export default config;
