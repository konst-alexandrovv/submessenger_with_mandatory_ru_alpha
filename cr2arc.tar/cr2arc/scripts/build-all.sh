#!/bin/bash

set -e

# Очистка
echo "Удаление временных файлов"
rm -rf node_modules package-lock.json dist dist_electron

# Установка зависимостей
echo "Установка базовых зависимостей"
npm install

# Генерация package-lock.json
echo "Генерация package-lock.json"
npm i --package-lock-only

# Проверка наличия необходимых директорий
echo "Проверка наличия необходимых директорий"
mkdir -p dist

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# Список доступных платформ
PLATFORMS=(
  "web:Веб-версия"
  "pwa:Progressive Web App"
  "electron-win:Windows (x64)"
  "electron-mac:macOS (x64, arm64)"
  "electron-linux:Linux (x64, arm64)"
  "android:Android (arm64, x64)"
  "ios:iOS (arm64)"
  "docker:Docker контейнер"
)

# Функция для проверки зависимостей
check_dependencies() {
  local missing=()
  
  # Основные зависимости
  command -v node >/dev/null 2>&1 || missing+=("nodejs")
  command -v npm >/dev/null 2>&1 || missing+=("npm")
  
  # Платформо-зависимые
  if [[ " ${selected_platforms[@]} " =~ " electron-win " ]]; then
    command -v wine >/dev/null 2>&1 || missing+=("wine")
  fi
  
  if [[ " ${selected_platforms[@]} " =~ " android " ]]; then
    [[ -z "${ANDROID_HOME}" ]] && missing+=("android-sdk")
  fi
  
  if [[ " ${selected_platforms[@]} " =~ " ios " ]]; then
    [[ "$(uname)" != "Darwin" ]] && {
      echo -e "${RED}iOS сборка возможна только на macOS${NC}"
      exit 1
    }
    command -v xcodebuild >/dev/null 2>&1 || missing+=("xcode")
  fi
  
  if [[ " ${selected_platforms[@]} " =~ " docker " ]]; then
    command -v docker >/dev/null 2>&1 || missing+=("docker")
    command -v docker-compose >/dev/null 2>&1 || missing+=("docker-compose")
  fi
  
  if [ ${#missing[@]} -ne 0 ]; then
    echo -e "${RED}Отсутствуют необходимые зависимости: ${missing[*]}${NC}"
    echo "Установите их и повторите попытку"
    exit 1
  fi
}

# Выбор платформ
echo "Доступные платформы для сборки:"
for i in "${!PLATFORMS[@]}"; do
  IFS=':' read -r id desc <<< "${PLATFORMS[$i]}"
  echo "$((i+1)). $desc"
done
echo "0. Собрать для всех платформ"

read -p "Выберите номера платформ через пробел (или 0 для всех): " -a choices

selected_platforms=()
if [[ "${choices[0]}" == "0" ]]; then
  for platform in "${PLATFORMS[@]}"; do
    IFS=':' read -r id _ <<< "$platform"
    selected_platforms+=("$id")
  done
else
  for choice in "${choices[@]}"; do
    if [[ $choice =~ ^[0-9]+$ ]] && [ "$choice" -le "${#PLATFORMS[@]}" ]; then
      IFS=':' read -r id _ <<< "${PLATFORMS[$((choice-1))]}"
      selected_platforms+=("$id")
    fi
  done
fi

# Проверка зависимостей
check_dependencies

# Очистка и установка зависимостей
echo "Установка зависимостей..."
rm -rf node_modules
npm ci

# Сборка для каждой выбранной платформы
for platform in "${selected_platforms[@]}"; do
  echo -e "${GREEN}Сборка для платформы: $platform${NC}"
  
  case $platform in
    "web")
      npm run build:web
      ;;
    "pwa")
      npm run build:pwa
      ;;
    "electron-win")
      npm run build:electron -- --win
      ;;
    "electron-mac")
      if [[ "$(uname)" == "Darwin" ]]; then
        npm run build:electron -- --mac
      else
        echo -e "${RED}Сборка для macOS возможна только на macOS${NC}"
      fi
      ;;
    "electron-linux")
      npm run build:electron -- --linux
      ;;
    "android")
      if [ -n "${ANDROID_HOME}" ]; then
        npx cap add android
	chmod +x android/gradlew
	npm run build:android
      else
        echo -e "${RED}Не настроен ANDROID_HOME${NC}"
      fi
      ;;
    "ios")
      if [[ "$(uname)" == "Darwin" ]]; then
        npm run build:ios
      else
        echo -e "${RED}Сборка для iOS возможна только на macOS${NC}"
      fi
      ;;
    "docker")
      docker-compose build
      ;;
  esac
done

echo -e "${GREEN}Сборка завершена!${NC}"
echo "Результаты сборки находятся в следующих директориях:"
echo "- web: ./dist"
echo "- electron: ./dist_electron"
echo "- android: ./android/app/build/outputs/apk"
echo "- ios: ./ios/App/build"
