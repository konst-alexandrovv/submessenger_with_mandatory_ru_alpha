#!/bin/bash

set -e

# Check requirements
command -v docker >/dev/null 2>&1 || { echo "Docker required" >&2; exit 1; }
command -v docker-compose >/dev/null 2>&1 || { echo "Docker Compose required" >&2; exit 1; }

# Build app
echo "Building application..."
npm run build:web

# Deploy containers
echo "Deploying containers..."
docker-compose up -d --build

# Cleanup
echo "Cleaning up..."
docker image prune -f

echo "Deployment complete"
