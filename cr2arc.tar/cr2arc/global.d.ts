/// <reference types="vite/client" />
/// <reference types="node" />

declare namespace NodeJS {
  interface ProcessEnv {
    NODE_ENV: 'development' | 'production' | 'test';
    VITE_APP_TITLE: string;
    // Добавьте другие переменные окружения по необходимости
  }
}

declare module '@/components/ui/*' {
  const component: any;
  export default component;
}

declare module '*.svg' {
  const content: string;
  export default content;
}

declare module 'openpgp' {
  export interface WebStream<T> {
    toString(): string;
  }
  
  export interface Message<T> {
    type: 'text' | 'binary';
    data: T;
  }
}

interface Window {
  electron: {
    send: (channel: string, data: any) => void;
    receive: (channel: string, func: (...args: any[]) => void) => void;
    invoke: <T = any>(channel: string, data?: any) => Promise<T>;
  };
  fs: {
    readFile: (path: string, options?: { encoding?: string }) => Promise<Uint8Array | string>;
    writeFile: (path: string, data: Uint8Array | string) => Promise<void>;
    exists: (path: string) => Promise<boolean>;
  };
}

// Дополнительные глобальные типы
declare type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

declare type Nullable<T> = T | null;

declare type ValueOf<T> = T[keyof T];
